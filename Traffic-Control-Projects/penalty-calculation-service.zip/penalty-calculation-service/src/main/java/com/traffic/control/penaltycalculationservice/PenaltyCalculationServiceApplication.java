package com.traffic.control.penaltycalculationservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PenaltyCalculationServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PenaltyCalculationServiceApplication.class, args);
	}

}
